document.getElementById("h2Profesion").onclick = function () {window.location.hash = "#Profesion";
};